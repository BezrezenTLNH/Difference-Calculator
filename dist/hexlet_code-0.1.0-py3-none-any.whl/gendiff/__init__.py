print('__init__gendiff')

__all__ = ['gendiff']
