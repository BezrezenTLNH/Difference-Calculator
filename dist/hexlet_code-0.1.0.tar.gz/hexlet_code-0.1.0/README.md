### Hexlet tests and linter status:
[![Actions Status](https://github.com/BezrezenTLNH/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/BezrezenTLNH/python-project-50/actions)
[![Actions my](https://github.com/BezrezenTLNH/python-project-50/workflows/gendiff_check/badge.svg)](https://github.com/BezrezenTLNH/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/47159c5984cb798b8c74/maintainability)](https://codeclimate.com/github/BezrezenTLNH/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/47159c5984cb798b8c74/test_coverage)](https://codeclimate.com/github/BezrezenTLNH/python-project-50/test_coverage)

[![asciicast](https://asciinema.org/a/0yzMciomV8aHRj7lH3IabX4Ey.png)](https://asciinema.org/a/0yzMciomV8aHRj7lH3IabX4Ey)