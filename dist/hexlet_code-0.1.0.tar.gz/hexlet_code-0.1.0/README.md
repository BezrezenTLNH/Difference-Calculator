### Hexlet tests and linter status:
[![Actions Status](https://github.com/BezrezenTLNH/python-project-50/workflows/gendiff_check/badge.svg)](https://github.com/BezrezenTLNH/python-project-50/actions)
<a href="https://codeclimate.com/github/BezrezenTLNH/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/47159c5984cb798b8c74/maintainability" /></a>
<a href="https://codeclimate.com/github/BezrezenTLNH/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/47159c5984cb798b8c74/test_coverage" /></a>