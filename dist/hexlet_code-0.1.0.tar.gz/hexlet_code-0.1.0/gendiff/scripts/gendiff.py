import argparse

def main():
    print('Print -h flag to check the information')


if __name__ == '__main__':
    main()